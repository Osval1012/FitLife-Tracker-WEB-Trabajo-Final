// scripts.js

document.addEventListener('DOMContentLoaded', function() {
  // 1) Toggle menú móvil
  const navToggle = document.getElementById('nav-toggle');
  const mainNav = document.getElementById('main-nav');

  if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
      mainNav.classList.toggle('open');
    });
  }

  // 2) Validación simple del formulario en contacto
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const name = document.getElementById('name').value.trim();
      const email = document.getElementById('email').value.trim();
      const message = document.getElementById('message').value.trim();
      const feedback = document.getElementById('form-message');

      if (!name || !email || !message) {
        feedback.textContent = 'Por favor completa todos los campos.';
        feedback.style.color = 'crimson';
        return;
      }

      // validación básica de email
      const re = /\S+@\S+\.\S+/;
      if (!re.test(email)) {
        feedback.textContent = 'Por favor ingresa un correo válido.';
        feedback.style.color = 'crimson';
        return;
      }

      // Simular envío
      feedback.textContent = 'Enviando...';
      feedback.style.color = '#333';

      setTimeout(() => {
        feedback.textContent = '¡Mensaje enviado! Gracias por contactarnos.';
        feedback.style.color = 'green';
        contactForm.reset();
      }, 900);
    });
  }

  // 3) Efecto simple al hacer scroll (reveal)
  const revealElements = document.querySelectorAll('.card, .post, .testimonials blockquote');
  const revealOnScroll = () => {
    const windowBottom = window.innerHeight;
    revealElements.forEach(el => {
      const rect = el.getBoundingClientRect();
      if (rect.top < windowBottom - 60) {
        el.style.opacity = 1;
        el.style.transform = 'translateY(0)';
      }
    });
  };
  // setup initial styles
  revealElements.forEach(el => {
    el.style.opacity = 0;
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'all 600ms ease';
  });
  window.addEventListener('scroll', revealOnScroll);
  revealOnScroll();
});
